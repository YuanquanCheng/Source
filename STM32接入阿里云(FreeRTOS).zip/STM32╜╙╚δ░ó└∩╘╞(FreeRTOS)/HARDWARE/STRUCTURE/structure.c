#include "structure.h"


struct xRecMsg WifiMsg;
struct xDevice Device;

