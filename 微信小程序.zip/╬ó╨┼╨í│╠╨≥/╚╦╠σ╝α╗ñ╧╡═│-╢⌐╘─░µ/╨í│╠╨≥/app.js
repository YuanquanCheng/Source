// // app.js

// const mqtt = require('./utils/mqtt.js');
// const aliyunOpt = require('./utils/aliyun/aliyun_connect.js');

// App({
//   onLaunch: function () {
//     let that = this;
//     let aliyunInfo = {
//       productKey: 'k0urhI6ywuP',
//       deviceName: 'WECHAT',
//       deviceSecret: 'c26ef7a8103aaee9141fb34e3ade7a74',
//       regionId: 'cn-shanghai',
//       pubTopic: '/k0urhI6ywuP/WECHAT/user/WECHAT',
//       subTopic: '/k0urhI6ywuP/WECHAT/user/get',
//     };

//     let clientOpt = aliyunOpt.getAliyunIotMqttClient(aliyunInfo);
//     let host = 'wxs://' + clientOpt.host;

//     that.globalData.mqttClient = mqtt.connect(host, {
//       protocolVersion: 4,
//       clean: false,
//       reconnectPeriod: 1000,
//       connectTimeout: 30 * 1000,
//       resubscribe: true,
//       clientId: clientOpt.clientId,
//       password: clientOpt.password,
//       username: clientOpt.username,
//     });

//     that.globalData.mqttClient.on('connect', function (connack) {
//       console.log("连接成功");
//       wx.showToast({
//         title: '连接成功',
//         icon: 'none', // 提示图标，有效值 "success", "loading", "none"，其中"none"表示不显示图标
//         duration: 2000 // 提示的延迟时间，单位毫秒，默认值是1500
//       })

//       // 订阅主题
//       that.globalData.mqttClient.subscribe(aliyunInfo.subTopic, function (err) {
//         if (!err) {
//           console.log("订阅成功");
//           wx.showToast({
//             title: '订阅成功',
//             icon: 'none', // 提示图标，有效值 "success", "loading", "none"，其中"none"表示不显示图标
//             duration: 2000 // 提示的延迟时间，单位毫秒，默认值是1500
//           })
//         } else {
//           console.error("订阅失败:", err);
//           wx.showToast({
//             title: '订阅失败',
//             icon: 'none', // 提示图标，有效值 "success", "loading", "none"，其中"none"表示不显示图标
//             duration: 2000 // 提示的延迟时间，单位毫秒，默认值是1500
//           })
//         }
//       });
//     });

//     that.globalData.mqttClient.on('message', function (topic, payload) {
//       console.log('收到消息:', topic, payload.toString());
//       // 处理接收到的消息
//     });

//     that.globalData.mqttClient.on('error', function (error) {
//       console.error("服务器连接异常:", error);
//       wx.showToast({
//         title: '服务器连接异常',
//         icon: 'none', // 提示图标，有效值 "success", "loading", "none"，其中"none"表示不显示图标
//         duration: 2000 // 提示的延迟时间，单位毫秒，默认值是1500
//       })
//     });

//     that.globalData.mqttClient.on('reconnect', function () {
//       console.log("重新连接服务器");
//       wx.showToast({
//         title: '重新连接服务器',
//         icon: 'none', // 提示图标，有效值 "success", "loading", "none"，其中"none"表示不显示图标
//         duration: 2000 // 提示的延迟时间，单位毫秒，默认值是1500
//       })
//     });

//     that.globalData.mqttClient.on('offline', function () {
//       console.log("服务器连接已断开");
//       wx.showToast({
//         title: '服务器连接已断开',
//         icon: 'none', // 提示图标，有效值 "success", "loading", "none"，其中"none"表示不显示图标
//         duration: 2000 // 提示的延迟时间，单位毫秒，默认值是1500
//       })
//     });
//   },
//   globalData: {
//     mqttClient: null
//   }
// })
// app.js

const mqtt = require('./utils/mqtt.js');
const aliyunOpt = require('./utils/aliyun/aliyun_connect.js');

App({
  // 连接阿里云
  connectAliyun: function (aliyunInfo) {
    // 检查参数完整性
    if (!aliyunInfo.productKey || !aliyunInfo.deviceName || !aliyunInfo.deviceSecret) {
      // 如果缺少参数，则提示用户输入相关信息
      wx.showToast({
        title: '请输入完整的连接信息',
        icon: 'none',
        duration: 2000
      });
      return; // 终止连接操作
    }
    let that = this;
    let clientOpt = aliyunOpt.getAliyunIotMqttClient(aliyunInfo);
    let host = 'wxs://' + clientOpt.host;

    that.globalData.mqttClient = mqtt.connect(host, {
      protocolVersion: 4,
      clean: false,
      reconnectPeriod: 1000,
      connectTimeout: 30 * 1000,
      resubscribe: true,
      clientId: clientOpt.clientId,
      password: clientOpt.password,
      username: clientOpt.username,
    });

    that.globalData.mqttClient.on('connect', function (connack) {
      console.log("连接成功");
      that.globalData.isConnected = true;
      wx.showToast({
        title: '连接成功',
        icon: 'none',
        duration: 2000
      })
    });

    that.globalData.mqttClient.on('error', function (error) {
      console.error("服务器连接异常:", error);
      wx.showToast({
        title: '服务器连接异常',
        icon: 'none',
        duration: 2000
      })
    });

    // that.globalData.mqttClient.on('reconnect', function () {
    //   console.log("重新连接服务器");
    //   wx.showToast({
    //     title: '重新连接服务器',
    //     icon: 'none',
    //     duration: 2000
    //   })
    // });

    that.globalData.mqttClient.on('offline', function () {
      console.log("服务器连接已断开");
      wx.showToast({
        title: '服务器连接已断开',
        icon: 'none',
        duration: 2000
      })
    });
  },

  // 订阅主题
  subscribeTopic: function (subTopic) {
    if (!this.globalData.mqttClient) {
      // 如果未建立连接，则提示用户先连接服务器
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      });
      return; // 终止订阅操作
    }
    let that = this;
    that.globalData.mqttClient.subscribe(subTopic, function (err) {
      if (!err) {
        console.log("订阅成功");
        wx.showToast({
          title: '订阅成功',
          icon: 'none',
          duration: 2000
        })
      } else {
        console.error("订阅失败:", err);
        wx.showToast({
          title: '订阅失败',
          icon: 'none',
          duration: 2000
        })
      }
    });
  },

  globalData: {
    aliyunInfo: {
      productKey: '',
      deviceName: '',
      deviceSecret: '',
      pubTopic: '',
      subTopic: ''
    },
    isConnected: false,
    mqttClient: null
  },
  disconnectAliyun: function () {
    // 判断是否存在连接实例
    if (this.globalData.mqttClient) {
      // 断开连接
      this.globalData.mqttClient.end();
      // 将连接实例置为空
      this.globalData.mqttClient = null;
      // 重置阿里云连接相关的配置信息为初始值
      this.globalData.aliyunInfo = {
        productKey: 'k0urhI6ywuP',
        deviceName: 'WECHAT',
        deviceSecret: 'c26ef7a8103aaee9141fb34e3ade7a74',
        regionId: 'cn-shanghai',
        pubTopic: '/k0urhI6ywuP/WECHAT/user/WECHAT',
        subTopic: '/k0urhI6ywuP/WECHAT/user/get'
      };
      console.log("断开连接成功");
      this.globalData.isConnected = flase;
      wx.showToast({
        title: '断开连接成功',
        icon: 'none',
        duration: 2000
      });
    } else {
      console.log("未建立连接，无需断开");
      wx.showToast({
        title: '未建立连接，无需断开',
        icon: 'none',
        duration: 2000
      });
    }
  },
})
