// pages/connect/connect.js

Page({
  onLoad: function() {
    // 设置导航栏背景颜色为 #f0f0f0
    wx.setNavigationBarColor({
      // backgroundColor: '#007bff', // 导航栏背景颜色为 #f0f0f0
    });
  },
  data: {
    aliyunInfo: {
      productKey: 'k0urhI6ywuP',
      deviceName: 'WECHAT',
      deviceSecret: 'c26ef7a8103aaee9141fb34e3ade7a74',
      regionId: 'cn-shanghai',
      pubTopic: '/k0urhI6ywuP/WECHAT/user/WECHAT',
      subTopic: '/k0urhI6ywuP/WECHAT/user/get'
    },
    scanaliyunInfo: {
      productKey: '',
      deviceName: '',
      deviceSecret: '',
      regionId: '',
      pubTopic: '',
      subTopic: ''
    }
  },

  handleInput: function (e) {
    const name = e.currentTarget.dataset.name;
    const value = e.detail.value;
    this.setData({
      ['aliyunInfo.' + name]: value
    });
  },

  connect: function () {
    const aliyunInfo = this.data.aliyunInfo;
    // 调用全局方法连接阿里云
    console.log(aliyunInfo);
    getApp().connectAliyun(aliyunInfo);
  },
  disconnect: function () {
    // 调用全局方法断开阿里云连接
    getApp().disconnectAliyun();
  },
  sub: function () {
    const aliyunInfo = this.data.aliyunInfo;
    // 调用全局方法订阅主题
    getApp().subscribeTopic(aliyunInfo.subTopic);
    getApp().globalData.pubTopic=this.data.aliyunInfo.pubTopic;
    console.log("getApp().globalData.pubTopic"+getApp().globalData.pubTopic);
    console.log("this.data.aliyunInfo.pubTopic"+this.data.aliyunInfo.pubTopic);
  },
  // 扫描二维码
  scanQRCode: function () {
    const that = this;
    wx.scanCode({
      success:(res) =>{
        console.log(res.result); // 打印扫描结果
        // 解析扫描结果
        const result = res.result;
        // 假设扫描结果为一个JSON字符串，解析为对象
        const qrData = JSON.parse(result);
        // 更新页面数据
        that.setData({
          'scanaliyunInfo.productKey': qrData.productKey,
          'scanaliyunInfo.deviceName': qrData.deviceName,
          'scanaliyunInfo.deviceSecret': qrData.deviceSecret,
          'scanaliyunInfo.regionId': 'cn-shanghai',
          'scanaliyunInfo.pubTopic': qrData.pubTopic,
          'scanaliyunInfo.subTopic': qrData.subTopic
        });
        // console.log('aliyunInfo.productKey'+qrData.productKey,
        // 'aliyunInfo.deviceName'+qrData.deviceName,
        // 'aliyunInfo.deviceSecret'+qrData.deviceSecret,
        // 'aliyunInfo.regionId'+'cn-shanghai',
        // 'aliyunInfo.pubTopic'+qrData.pubTopic,
        // 'aliyunInfo.subTopic'+qrData.subTopic);
        console.log(this.data.scanaliyunInfo);
        getApp().connectAliyun(this.data.scanaliyunInfo);
        getApp().subscribeTopic(this.data.scanaliyunInfo);
      },
      fail(res) {
        console.log(res);
      }
    });
    
  }
})
