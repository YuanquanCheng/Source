// pages/dataPage/dataPage.js
import * as echarts from '../../ec-canvas/echarts';
// let chart=null
var chart = null;
var chart2 = null;
var chart3 = null;
let flag=0;
Page({
  // onShow: function() {
    // 判断连接状态，如果未连接，则重定向到连接页面
  //   if (!getApp().globalData.isConnected) {
  //     wx.redirectTo({
  //       url: '/Pages/lot/lot'
  //     });
  //     wx.showToast({
  //       title: '请先连接阿里云',
  //       icon: 'none',
  //       duration: 2000
  //     });
  //   }
  // },

data:{
  temperature:0,//温度
  Humidity:0,//湿度
  light:0,//光照
  low:101,
  high:0,
  average:0,

  low2:101,
  high2:0,
  average2:0,

  low3:101,
  high3:0,
  average3:0,
  ec: {
    onInit: initChart
  },
  ec2: {
    // lazyLoad: true,
    onInit: initChart2
  },
  ec3: {
    onInit: initChart3
  },
  tempData: [] ,// 存储心跳数据
  HumidityData: [], // 存储心跳数据
  LightData: [] // 存储光照数据
},

//----------------------------------------------
  onShow: function () {
      if (!getApp().globalData.mqttClient) {
      wx.showToast({
        title: '请先连接阿里云',
        icon: 'none',
        duration: 2000
      });
      return;
    }
    const app = getApp()
    const mqttClient = app.globalData.mqttClient

    // 监听 MQTT 接收到的消息
    mqttClient.on("message", function (topic, payload) {
      // 解析接收到的数据
      console.log(payload);
      let dataFromALY = JSON.parse(payload);
      console.log(dataFromALY);
      try{
        if (dataFromALY && dataFromALY.params && dataFromALY.params.temp !== undefined && dataFromALY.params.temp !== 0) 
        {
          let newtempData = this.data.tempData.concat(dataFromALY.params.temp);//ec
          if (newtempData.length > 100) 
          {
            newtempData = newtempData.slice(newtempData.length - 100); // 如果超过最大长度，截取数组末尾部分
          }
          console.log('温度数据：', newtempData,'温度数据长度：',newtempData.length);
          this.setData({
            temperature:dataFromALY.params.temp,
            tempData: newtempData,//ec
            average:Math.floor((this.data.temperature + this.data.average) / 2)
          });
          this.updateChart();
          if(dataFromALY.params.temp<this.data.low)
          {
            this.setData({low:dataFromALY.params.temp});
          }
          if(dataFromALY.params.temp>this.data.high)
          {
            this.setData({high:dataFromALY.params.temp});
          }
        }  
//=================湿度开始======
        if (dataFromALY && dataFromALY.params && dataFromALY.params.Humidity !== undefined && dataFromALY.params.Humidity !== 0) 
        {
          let newHumidityData = this.data.HumidityData.concat(dataFromALY.params.Humidity);//ec
          if (newHumidityData.length > 100) 
          {
            newHumidityData = newHumidityData.slice(newHumidityData.length - 100); // 如果超过最大长度，截取数组末尾部分
          }
          console.log('湿度数据：', newHumidityData,'湿度数据长度：',newHumidityData.length);
          this.setData({
            Humidity:dataFromALY.params.Humidity,
            HumidityData: newHumidityData,//ec
            average2:Math.floor((this.data.Humidity + this.data.average2) / 2)
          });
          this.updateChart();
          if(dataFromALY.params.Humidity<this.data.low2)
          {
            this.setData({low2:dataFromALY.params.Humidity});
          }
          if(dataFromALY.params.Humidity>this.data.high2)
          {
            this.setData({high2:dataFromALY.params.Humidity});
          }
        }  
//----------------湿度结束---------------------------------
//=================光照开始================================
if (dataFromALY && dataFromALY.params && dataFromALY.params.light !== undefined) 
{
  flag++;
  let newLightData = this.data.LightData.concat(dataFromALY.params.light);//ec
  if (newLightData.length > 100) 
  {
    newLightData = newLightData.slice(newLightData.length - 100); // 如果超过最大长度，截取数组末尾部分
  }
  console.log('光照数据：', newLightData,'光照数据长度：',newLightData.length);
  this.setData({
    light:dataFromALY.params.light,
    LightData: newLightData,//ec
    // average3:Math.floor((this.data.light + this.data.average3) / 2)
  });
    if(flag=1)
    {
      this.setData({average3:this.data.light});
    }
    else
    {
      this.setData({average3:Math.floor((this.data.light + this.data.average3) / 2)});
    }
  this.updateChart();
  if(dataFromALY.params.light<this.data.low3)
  {
    this.setData({low3:dataFromALY.params.light});
  }
  if(dataFromALY.params.light>this.data.high3)
  {
    this.setData({high3:dataFromALY.params.light});
  }
}  
//----------------光照结束------------------
        } 
        catch (error) {console.log(error);}
        }.bind(this));

        
  },
//========================================================================
  updateChart: function () {
    // console.log('updateChart 函数被调用了11111111111')
    if (chart) {
      // console.log('updateChart 函数被调用了222222222222')
      chart.setOption({
      //   title: {   // 添加title属性设置图表的标题
      //     text: '温度变化趋势图',  // 设置图表标题内容为'温度变化趋势图'
      //     textStyle: {  // 设置标题样式
      //         // color: '#333', // 标题文字颜色
      //         fontSize: 16,  // 标题文字大小
      //         // fontWeight: 'bold'  // 标题文字加粗
      //     },
      //     left: 'center'  // 设置标题水平居中
      // },
        // tooltip: {
        //   trigger: 'axis'
        // },
        xAxis: {
          // type: 'category',
          // boundaryGap: false,
          data: this.data.tempData.map((item, index) => index + 1) // X 轴数据，根据实际情况填充
        },
        // yAxis: {
        //   type: 'value'
        // },
        series: [{
          data: this.data.tempData, // Y 轴数据，根据实际情况填充
        //   type: 'line',
        //   smooth: true,
        //   lineStyle: {   // 添加lineStyle属性设置折线的样式
        //     color: 'blue'  // 设置折线的颜色为蓝色
        // }
        }]
      });
    }
    //==================湿度开始==============================
    if (chart2) {
      // console.log('updateChart 函数被调用了222222222222')
      chart2.setOption({
        // title: {   // 添加title属性设置图表的标题
          // text: '湿度变化趋势图',  // 设置图表标题内容为'温度变化趋势图'
          // textStyle: {  // 设置标题样式
              // color: '#333', // 标题文字颜色
              // fontSize: 16,  // 标题文字大小
              // fontWeight: 'bold'  // 标题文字加粗
          // },
          // left: 'center'  // 设置标题水平居中
      // },
        tooltip: {
          trigger: 'axis'
        },
        xAxis: {
          // type: 'category',
          // boundaryGap: false,
          data: this.data.HumidityData.map((item, index) => index + 1) // X 轴数据，根据实际情况填充
        },
        // yAxis: {
        //   type: 'value'
        // },
        series: [{
          data: this.data.HumidityData, // Y 轴数据，根据实际情况填充
        //   type: 'line',
        //   smooth: true,
        //   lineStyle: {   // 添加lineStyle属性设置折线的样式
        //     color: 'green'  // 设置折线的颜色为蓝色
        // }
        }]
      });
    }
    //==================湿度结束=============================
    //==================光照开始==============================
    if (chart3) {
      // console.log('updateChart 函数被调用了222222222222')
      chart3.setOption({
        // title: {   // 添加title属性设置图表的标题
          // text: '湿度变化趋势图',  // 设置图表标题内容为'温度变化趋势图'
          // textStyle: {  // 设置标题样式
              // color: '#333', // 标题文字颜色
              // fontSize: 16,  // 标题文字大小
              // fontWeight: 'bold'  // 标题文字加粗
          // },
          // left: 'center'  // 设置标题水平居中
      // },
        tooltip: {
          trigger: 'axis'
        },
        xAxis: {
          // type: 'category',
          // boundaryGap: false,
          data: this.data.LightData.map((item, index) => index + 1) // X 轴数据，根据实际情况填充
        },
        // yAxis: {
        //   type: 'value'
        // },
        series: [{
          data: this.data.LightData, // Y 轴数据，根据实际情况填充
        //   type: 'line',
        //   smooth: true,
        //   lineStyle: {   // 添加lineStyle属性设置折线的样式
        //     color: 'green'  // 设置折线的颜色为蓝色
        // }
        }]
      });
    }
    //==================光照结束=============================
  },
    //========================================================================
  //--------------------------------
  Things1CMD(a){
          var status=a.detail.value
          var that=this
             if(status==true){
              that.sendCommond(1);
             }else{
              that.sendCommond(0);
             }
        },
  //----------------------------------
  onClickOpen() {
    that.sendCommond(1);
  },
  onClickOff() {
    that.sendCommond(0);
  },
  sendCommond(data) {
    let sendData = {
      LEDSTATE: data,
      // LED_Control:data,
    };
    

// //此函数是订阅的函数，因为放在访问服务器的函数后面没法成功订阅topic，因此把他放在这个确保订阅topic的时候已成功连接服务器
// //订阅消息函数，订阅一次即可 如果云端没有订阅的话，需要取消注释，等待成功连接服务器之后，在随便点击（开灯）或（关灯）就可以订阅函数
//    /*this.data.client.subscribe(this.data.aliyunInfo.subTopic,function(err){
//       if(!err){
//         console.log("订阅成功");
//       };
//       wx.showModal({
//         content: "订阅成功",
//         showCancel: false,
//       })
//     })  
//   */

    //发布消息
    // pubTopic: '/k0urhI6ywuP/WECHAT/user/WECHAT'//发布消息的主题
    const app = getApp()
    const mqttClient = app.globalData.mqttClient
    if (mqttClient && mqttClient.connected) {
      mqttClient.publish('/k0urhI6ywuP/WECHAT/user/WECHAT', JSON.stringify(sendData));
      console.log('/k0urhI6ywuP/WECHAT/user/WECHAT')
      console.log(JSON.stringify(sendData))
    } else {
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      })
    }
  }
})



function initChart(canvas, width, height,dpr) {
  chart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio:dpr
  })
  canvas.setChart(chart)

  var option = ({
    title: {   // 添加title属性设置图表的标题
      text: '温度变化趋势图',  // 设置图表标题内容为'心率变化趋势图'
      textStyle: {  // 设置标题样式
          color: '#333', // 标题文字颜色
          fontSize: 16,  // 标题文字大小
          // fontWeight: 'bold'  // 标题文字加粗
      },
      left: 'center'  // 设置标题水平居中
      },
    tooltip: {
      trigger: 'axis'
    },
    dataZoom: [ // 设置数据缩放和滚动功能
      {
          type: 'inside', // 内置数据缩放和滚动
          start: 0, // 默认开始位置
          end: 100, // 默认结束位置
      },
      {
        type: 'slider', // 滑动条数据缩放和滚动
        start: 0, // 默认开始位置
        end: 100, // 默认结束位置
        bottom: 10, // 滑动条位置
        showDetail: false, // 不显示数据缩放的详细信息
        // 设置滑动条的宽度，根据实际需求调整
        width: '90%',
        // 设置初始的滑动条选中范围，显示最后30个点的数据
        // startValue: Math.max(0, 100 - 30 / (30 + data.length) * 100)
        left: 'center', // 设置滚动条居中
        right: 'center' // 设置滚动条居中
      }
    ],
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: [] // X 轴数据，根据实际情况填充
    },
    yAxis: {
      type: 'value',
      min: 0,  // 设置y轴最小值
      max: 100,
    },
    series: [{
      data: [], // Y 轴数据，根据实际情况填充
      type: 'line',
      smooth: true,
      lineStyle: {   // 添加lineStyle属性设置折线的样式
        color: 'blue'  // 设置折线的颜色为红色
    }
    }]
  });

// //-----------------------------------------
  chart.setOption(option)
  return chart
}

function initChart2(canvas, width, height,dpr) {
  chart2 = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio:dpr
  })
  canvas.setChart(chart2)

  var option2 = ({
    title: {   // 添加title属性设置图表的标题
      text: '湿度变化趋势图',  // 设置图表标题内容为'心率变化趋势图'
      textStyle: {  // 设置标题样式
          // color: '#333', // 标题文字颜色
          fontSize: 16,  // 标题文字大小
          // fontWeight: 'bold'  // 标题文字加粗
      },
      left: 'center'  // 设置标题水平居中
      },
    tooltip: {
      trigger: 'axis'
    },
    dataZoom: [ // 设置数据缩放和滚动功能
      {
          type: 'inside', // 内置数据缩放和滚动
          start: 0, // 默认开始位置
          end: 100, // 默认结束位置
      },
      {
        type: 'slider', // 滑动条数据缩放和滚动
        start: 0, // 默认开始位置
        end: 100, // 默认结束位置
        bottom: 10, // 滑动条位置
        showDetail: false, // 不显示数据缩放的详细信息
        // 设置滑动条的宽度，根据实际需求调整
        width: '90%',
        // 设置初始的滑动条选中范围，显示最后30个点的数据
        // startValue: Math.max(0, 100 - 30 / (30 + data.length) * 100)
        left: 'center', // 设置滚动条居中
        right: 'center' // 设置滚动条居中
      }
    ],
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: [] // X 轴数据，根据实际情况填充
    },
    yAxis: {
      type: 'value',
      min: 0,  // 设置y轴最小值
      max: 100,
    },
    series: [{
      data: [], // Y 轴数据，根据实际情况填充
      type: 'line',
      smooth: true,
      lineStyle: {   // 添加lineStyle属性设置折线的样式
        color: 'green'  // 设置折线的颜色为红色
    }
    }]
  });

// //-----------------------------------------
  chart2.setOption(option2)
  return chart2
}
//=======================光照图配置================================================
function initChart3(canvas, width, height,dpr) {
  chart3 = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio:dpr
  })
  canvas.setChart(chart3)

  var option3 = ({
    title: {   // 添加title属性设置图表的标题
      text: '光照变化趋势图',  // 设置图表标题内容为'光照变化趋势图'
      textStyle: {  // 设置标题样式
          // color: '#333', // 标题文字颜色
          fontSize: 16,  // 标题文字大小
          // fontWeight: 'bold'  // 标题文字加粗
      },
      left: 'center'  // 设置标题水平居中
      },
    tooltip: {
      trigger: 'axis'
    },
    dataZoom: [ // 设置数据缩放和滚动功能
      {
          type: 'inside', // 内置数据缩放和滚动
          start: 0, // 默认开始位置
          end: 100, // 默认结束位置
      },
      {
        type: 'slider', // 滑动条数据缩放和滚动
        start: 0, // 默认开始位置
        end: 100, // 默认结束位置
        bottom: 10, // 滑动条位置
        showDetail: false, // 不显示数据缩放的详细信息
        // 设置滑动条的宽度，根据实际需求调整
        width: '90%',
        // 设置初始的滑动条选中范围，显示最后30个点的数据
        // startValue: Math.max(0, 100 - 30 / (30 + data.length) * 100)
        left: 'center', // 设置滚动条居中
        right: 'center' // 设置滚动条居中
      }
    ],
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: [] // X 轴数据，根据实际情况填充
    },
    yAxis: {
      type: 'value',
      min: 0,  // 设置y轴最小值
      // max: 65535,
      max: 15000,
    },
    series: [{
      data: [], // Y 轴数据，根据实际情况填充
      type: 'line',
      smooth: true,
      lineStyle: {   // 添加lineStyle属性设置折线的样式
        color: 'purple'  // 设置折线的颜色为绿色
    }
    }]
  });
  chart3.setOption(option3)
  return chart3
}